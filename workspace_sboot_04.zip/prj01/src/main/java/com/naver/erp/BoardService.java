package com.naver.erp;

public interface BoardService {
	
	//
	// [게시판 글 입력 후 입력 적용 행의 개수] 리턴하는 메소드 선언
	//
	int insertBoard(BoardDTO boardDTO);
	//
	// [1개 게시판 글]리턴하는 메소드 선언
	//
	BoardDTO getBoard(int b_no);
	//
	// [1개 게시판] 수정 실행하고 수정 적용행의 개수를 리턴하는 메소드 선언
	//
	int upDateBoard(BoardDTO boardDTO);
	
	//
	// [1개 게시판] 삭제 후 삭제 적용행의 개수를 리턴하는 메소드 선언 
	//
	int deleteBoard(BoardDTO boardDTO);
	
}









	//인터페이스 안에 있는 모든 메소드, 속성변수는 기본적으로 퍼블릭성격을 가진다(없다고 없는게 아니다
	//public과 static, final의 성격을 가진 속성변수
	//public과 abstract의 성격을 가진 메소드로 구성된
	//클래스와는 다른 단위 프로그램의 한 종류

