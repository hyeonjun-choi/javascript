package com.naver.erp;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

//====================================================================
// URL 주소로 접속하면 호출되는 메소드를 소유한 [컨트롤러 클래스]선언
// @Controller를 붙임으로써 [컨트롤러 클래스]임을 지정한다.
//====================================================================
@Controller
public class LoginController {
	
	/*
	//-----------------------------------------------------------------------------------
	// SqlSessionTemplate 객체를 생성해 속성변수 sqlSession에 저장
	// @Autowired 어노테이션을 붙이면 자료형에 맞는 SqlSessionTemplate 객체를 생성한다.
	// 결국 속성변수 sqlSession 에는 SqlSessionTemplate 객체의 메위주가 저장되어 있다.
	// SqlSessionTemplate 객체의 메소드를 이용하면 xml에 저장된 SQL 구문을 읽어 DB 연동 할 수 있다.
	//-----------------------------------------------------------------------------------
	@Autowired
	private SqlSessionTemplate sqlSession;
	*/
	
	
	// 속성변수 -- 메소드를 선언할 데이터
	//-----------------------------------------------------------------------------------
	// 속성변수 loginDAO 선언하고, LoginDAO 라는 인터페이스를
	// 구현한 클래스를 객체화하여 저장
	// 즉 속성변수 loginDAO 에는 LoginDAOImple 객체의 메위주가 저장된다.
	//-----------------------------------------------------------------------------------
		// @Autowired 이 붙은 속성변수에는 인터페이스 자료형을 쓰고
		// 이 인터페이스를 구현한 클래스를 객체화하여 저장한다.
		// LoginDAO 라는 인터페이스를 구현한 클래스의 이름을 몰라도 관계없다
		// 1개만 존재하기만 하면 된다.
	//-----------------------------------------------------------------------------------
	//=============================================
	// @Autowired
	// 인터페이스명 속성변수;
	//=============================================
		// 인터페이스를 구현한 클래스를 찾아서 객체화한 후 객체의 메위주를 속성변수에 저장한다
		// 객체의 이름은 무엇이든 상관없다. 인터페이스를 구현한 객체이면 된다
		// 즉 속성변수에는 null 저장이 아니다
		// <주의> 인터페이스를 구현한 객체는 1개 이어야한다.
	@Autowired
	private LoginDAO loginDAO;		//(@Autowired 없을 시 loginDAO에는 null이 있음)
	//▲확장자명 ▲기본형|클래스명|인터페이스명 ▲속성변수;
	//				xxx가 클래스명 /// 클래스명의 메위주 혹은 후손 객체 메위주
	//				xxx가 인터페이스명 /// 인터페이스를 구현한 객체 메위주
	//				생성자,
	
	
	
	//====================================================================
	// 가상주소 /loginForm.do 로 접근하면 호출되는 메소드 선언
	//====================================================================
	@RequestMapping( value="/loginForm.do")
	public ModelAndView loginForm( ) {
		//System.out.println("오 되써......");
		//=======================================================
		// [ModelAndView 객체] 생성하기
		// [ModelAndView 객체] 에 [호출 JSP 페이지명] 을 저장하기
		// [ModelAndView 객체] 리턴하기
		//=======================================================
		ModelAndView mav = new ModelAndView();
		mav.setViewName("loginForm.jsp");
		return mav;		
	}
	
	//=======================================================
	// 가상주소 /loginProc.do 로 접근하면 호출되는 메소드 선언
	//=======================================================
	@RequestMapping( value="/loginProc.do")
	public ModelAndView loginProc(
				//--------------------------------------
				// "login_id" 라는 파라미터명에 해당하는 파라미터값을 꺼내서 매개변수 login_id 에 저장하고 들어온다.
				//--------------------------------------
				@RequestParam( value="login_id" ) String login_id
				//--------------------------------------
				// "pwd" 라는 파라미터명에 해당하는 파라미터값을 꺼내서 매개변수 pwd 에 저장하고 들어온다.
				//--------------------------------------
				, @RequestParam( value="pwd" ) String pwd

		){	
		
			//=======================================================
			// HashMap 객체 생성하기
			// HashMap 객체에 로그인 아이디 저장하기
			// HashMap 객체에 암호 저장하기
			//=======================================================
			Map<String,String> map = new HashMap<String,String>();
			map.put("login_id", login_id);
			map.put("pwd", pwd);
			
			
			//=======================================================
			// Login_idCnt 객체의 getLogin_idCnt 메소드를 호출하여
			// 로그인아이디와 암호의 전제 개수 얻기
			//=======================================================
			System.out.println( "LoginController.loginProc => " + 2);
			int login_idCnt = loginDAO.getLogin_idCnt(map);
			System.out.println( "LoginController.loginProc => " + 3);
			
			
			//System.out.println( "login_id => " + login_id );
			
			//System.out.println( "pwd => " + pwd );
			//=======================================================
			// [ModelAndView 객체] 생성하기
			// [ModelAndView 객체] 에 [호출 JSP 페이지명] 을 저장하기
			// [ModelAndView 객체] 에 아이디 암호 존재개수 저장하기. 즉, DB 연동 결과물 저장하기
			// ModelAndView 객체에 저장된 DB 연동 결과물은 HttpServletRequest 객체에 setAttribute 메소드로 저장된다.
			// [ModelAndView 객체] 리턴하기
			//=======================================================
			ModelAndView mav = new ModelAndView();
			mav.setViewName("loginProc.jsp");
			mav.addObject("idCnt", login_idCnt );		// DB 연동 결과물 저장, mav.addObject("idCnt", 변수 );
			// 위 addObject메소드로 저장된 DB 연동 결과물은 HttpServletRequest 객체에 setAttribute 메소드로 저장된다.
			
			System.out.println("LoginController.loginProc 메소드 호출 완료");
			
			return mav;
		}
		
		
	//=======================================================
	// 가상주소 /loginProc2.do 로 접근하면 호출되는 메소드 선언
	//=======================================================
	@RequestMapping( value="/loginProc2.do")
	public ModelAndView loginProc2(
			HttpServletRequest request

	){	
		
		String login_id = request.getParameter("login_id");
	    String pwd = request.getParameter("pwd");
	
		//=======================================================
		// HashMap 객체 생성하기
		// HashMap 객체에 로그인 아이디 저장하기
		// HashMap 객체에 암호 저장하기
		//=======================================================
		Map<String,String> map = new HashMap<String,String>();
		map.put("login_id", login_id);
		map.put("pwd", pwd);
		
		
		//=======================================================
		// Login_idCnt 객체의 getLogin_idCnt 메소드를 호출하여
		// 로그인아이디와 암호의 전제 개수 얻기
		//=======================================================
		System.out.println( "LoginController.loginProc => " + 2);
		int login_idCnt = loginDAO.getLogin_idCnt(map);
		System.out.println( "LoginController.loginProc => " + 3);
		
		
		//System.out.println( "login_id => " + login_id );
		
		//System.out.println( "pwd => " + pwd );
		//=======================================================
		// [ModelAndView 객체] 생성하기
		// [ModelAndView 객체] 에 [호출 JSP 페이지명] 을 저장하기
		// [ModelAndView 객체] 에 아이디 암호 존재개수 저장하기. 즉, DB 연동 결과물 저장하기
		// ModelAndView 객체에 저장된 DB 연동 결과물은 HttpServletRequest 객체에 setAttribute 메소드로 저장된다.
		// [ModelAndView 객체] 리턴하기
		//=======================================================
		ModelAndView mav = new ModelAndView();
		mav.setViewName("loginProc.jsp");
		mav.addObject("idCnt", login_idCnt );		// DB 연동 결과물 저장, mav.addObject("idCnt", 변수 );
		// 위 addObject메소드로 저장된 DB 연동 결과물은 HttpServletRequest 객체에 setAttribute 메소드로 저장된다.
		return mav;
	}

}

	
//int login_idCnt = loginDAO.getLogin_IdCnt(map);
	
	
	
	
